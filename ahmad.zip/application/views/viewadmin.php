<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Flat HTML5/CSS3 Login Form</title>
  
  

  
</head>

<body>
    <form class="register-form" >
   
    </form>
    <form class="login-form" action="<?php echo base_url('Adminlogin/aksi_login'); ?>" method="post">
      <input type="text" placeholder="username" name="username"/>
      <input type="password" placeholder="password" name="password"/>
      <button>login</button>
    </form>
  </div>
</div>

</body>
</html>